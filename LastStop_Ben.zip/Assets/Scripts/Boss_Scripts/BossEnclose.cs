using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class BossEnclose : MonoBehaviour
{
    public Transform rock1;
    public Transform rock2;
    public float fallSpeed = 100f;
    public float stopPoint = -13f;

    private bool isFalling = false;

    public CinemachineConfiner cinemachineConfiner;
    public Collider2D newBoundingShape;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(isFalling && rock1.position.y > stopPoint)
        {
            rock1.position += Vector3.down * fallSpeed * Time.deltaTime;
        }
        if(isFalling && rock2.position.y > stopPoint)
        {
            rock2.position += Vector3.down * fallSpeed * Time.deltaTime;
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
        isFalling = true;
        if (cinemachineConfiner != null && newBoundingShape != null)
            {
                cinemachineConfiner.m_BoundingShape2D = newBoundingShape;
                cinemachineConfiner.InvalidatePathCache();
            }
        }
    }
}
