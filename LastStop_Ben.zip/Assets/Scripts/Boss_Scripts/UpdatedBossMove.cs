using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpdatedBossMove : MonoBehaviour
{

    public float speed = 4f;
    public bool coolingdown = true;
    public bool shootingPlayer = false;
    public float cooldownTime = 3f;
    public float moveTime = 5f;

    public float minX;
    public float maxX;
    public Transform player;
    public float playerX;
    public GameObject bulletBoss;
    //public Transform bulletPos;
    private float timer;
    // Start is called before the first frame update
    void Start()
    {
        transform.rotation = Quaternion.identity;
    }

    // Update is called once per frame
    void Update()
    {
        if(!coolingdown)
        {
            transform.position += transform.right * speed * Time.deltaTime;
            moveTime -= Time.deltaTime;
            if(moveTime <= 0)
            {
                coolingdown = true;
                shootingPlayer = true;
                shootPlayer();
                moveTime = 4;
            }
        }
        else
        {
            cooldownTime -=Time.deltaTime;
            if (cooldownTime <= 0)
            {
                coolingdown = false;
                shootingPlayer = false;
                cooldownTime = 3;
            }
        }
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        if(col.gameObject.CompareTag("BossTurn"))
        {
            speed = speed * -1;
            Flip();
        }
    }

    void Flip()
    {
        Vector3 scaler = transform.localScale;
        scaler.x *= -1;
        transform.localScale = scaler;
    }

    void shootPlayer()
    {
        if (shootingPlayer == true)
            playerX = player.position.x;
            if(playerX >= minX && playerX <= maxX)
            {
                Instantiate(bulletBoss, transform.position, Quaternion.identity);
            }
    }
}
