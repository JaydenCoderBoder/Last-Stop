using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGame : MonoBehaviour
{
    [SerializeField] string scene;
    // Start is called before the first frame update
    void Start()
    {
        //SceneManager.LoadScene(scene.SampleScene);
    }

    // Update is called once per frame
    public void LoadOnClick()
    {
            SceneManager.LoadScene(scene);

    }
}
