using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthEnemy : MonoBehaviour
{
    [SerializeField] int hp = 1;
    // Start is called before the first frame update
    void Start()
    {
        
    }


    public void TakeDamage(int damage)
    {
        hp -=  damage;



        if(hp <=0)
        {
            Destroy(gameObject.transform.parent.gameObject);
            

        }
    }

    //void OnCollisionEnter2D(Collision2D collision)
    //{   
    //    Health objHealth;
    //    Debug.Log(collision.gameObject.tag);
    //    if(collision.gameObject.CompareTag("Bullet") && (gameObject.TryGetComponent(out objHealth)))
    //    {
    //        objHealth.TakeDamage(1);
    //    }
    //}
    void OnTriggerEnter2D(Collider2D col)
    {
        //Health objHealth;
        
        if(col.gameObject.CompareTag("Bullet"))// && (gameObject.TryGetComponent(out objHealth)))
        {
            TakeDamage(1);
        }
        if(col.gameObject.CompareTag("Feet"))
        {
            TakeDamage(1);
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Lava"))
        {
            TakeDamage(2);
        }
    }
}
