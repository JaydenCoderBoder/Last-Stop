using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class UpdatedGunController : MonoBehaviour
{
    [SerializeField] GameObject bullet;
    [SerializeField] GameObject gunObject;
    [SerializeField] float speed = 3;
    [SerializeField] private Animator gunAim;
    [SerializeField] private Transform gun;
    [SerializeField] private float gunDistance = 1.5f;

    private bool gunFacingRight = true;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector3 direction = mousePos - transform.position;

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        gun.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
        gun.position = transform.position + Quaternion.Euler(0, 0, angle) * new Vector3(gunDistance, 0, 0);

        if (angle > 90 || angle < -90)
        {
            if (gunFacingRight)
            {
                FlipGun();
            }
        }
        else
        {
            if (!gunFacingRight)
            {
                FlipGun();
            }
        }
    }

    void FlipGun()
    {
        gunFacingRight = !gunFacingRight;
        Vector3 scaler = gun.localScale;
        scaler.y *= -1;
        gun.localScale = scaler;

        // Rotate the gun 180 degrees on the y-axis
        Vector3 rotation = gun.localEulerAngles;
        rotation.y += 180;
        gun.localEulerAngles = rotation;
    }

    public void OnShoot(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            GameObject newBullet = Instantiate(bullet, gunObject.transform.position, Quaternion.identity);
            Vector2 shootDirection = gunFacingRight ? gunObject.transform.right : -gunObject.transform.right;
            newBullet.GetComponent<Rigidbody2D>().AddForce(shootDirection * speed, ForceMode2D.Impulse);
            newBullet.transform.right = shootDirection;
        }
    }
}