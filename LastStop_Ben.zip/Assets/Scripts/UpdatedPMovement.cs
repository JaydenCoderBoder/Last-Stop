using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class UpdatedPMovement : MonoBehaviour
{
    [SerializeField] float MoveSpeed;
    [SerializeField] float JumpPower;
    [SerializeField] private Animator animator;
    private Rigidbody2D rb;
    private bool isGrounded = true;
    private float move;
    private bool facingRight = true;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    void Move()
    {
        transform.position += Vector3.right * move * MoveSpeed * Time.deltaTime;


        if (move > 0 && !facingRight)
        {
            Flip();
        }
        else if (move < 0 && facingRight)
        {
            Flip();
        }

        animator.SetBool("isRunning", move != 0);
    }

    void Jump()
    {
        if (Input.GetButton("Jump") && Mathf.Abs(rb.velocity.y) < 0.001f)
        {
            rb.AddForce(Vector3.up * JumpPower, ForceMode2D.Impulse);
        }
    }

    public void OnMove(InputValue value)
    {
        move = value.Get<float>();
    }

    public void OnJump(InputValue value)
    {
        if (isGrounded)
        {
            Jump();
            isGrounded = false;
        }

    }

    void Flip()
    {
        facingRight = !facingRight;
        Vector3 scaler = transform.localScale;
        scaler.x *= -1;
        transform.localScale = scaler;

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }
}
