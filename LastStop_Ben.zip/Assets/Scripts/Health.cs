using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{
    [SerializeField] int hp = 3;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void TakeDamage(int damage)
    {
        hp -=  damage;



        if(hp <=0)
        {
            //Destroy(gameObject);
            //transform.position = new Vector3(0 * 0 * Time.deltaTime, 0 * Time.deltaTime, 0);
            //hp = 3;
            SceneManager.LoadScene("Title");

        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {   
        
        Health objHealth;
        //Debug.Break();
        if(collision.gameObject.CompareTag("Spike") && (gameObject.TryGetComponent(out objHealth)))
        {
            objHealth.TakeDamage(2);
        }
        if(collision.gameObject.CompareTag("Enemy") && (gameObject.TryGetComponent(out objHealth)))
        {
            objHealth.TakeDamage(3);
        }
        if(collision.gameObject.CompareTag("Lava") && (gameObject.TryGetComponent(out objHealth)))
        {
            objHealth.TakeDamage(3);
        }
        if(collision.gameObject.CompareTag("DeathFloor") && (gameObject.TryGetComponent(out objHealth)))
        {
            objHealth.TakeDamage(3);
        }
    }        
}
