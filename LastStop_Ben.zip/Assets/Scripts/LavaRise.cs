using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LavaRising2D : MonoBehaviour
{
  public Transform lava;
  public float riseSpeed = 1f;
  public float maxHeight = 10f;

  private bool isRising = false;

  void Start()
  {
    //lava.setActive(false);
  }

  void OnTriggerEnter2D(Collider2D other)
  {
    if (other.CompareTag("Player"))
    {
    isRising = true;
    }
  }

  void Update()
  {
    if (isRising && lava.position.y < maxHeight)
    {
      lava.position += Vector3.up * riseSpeed * Time.deltaTime;
      //lava.SetActive(true);
      //lava.size +- new Vector2(0,1 * riseSpeed);
    }
  }
}