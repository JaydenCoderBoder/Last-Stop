using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
public class GunController : MonoBehaviour
{

    [SerializeField] GameObject bullet;
    [SerializeField] GameObject gunObject;

    [SerializeField] float speed = 3;
    [SerializeField] private Animator gunAim;
    [SerializeField] private Transform gun;
    [SerializeField] private float gunDistance = 1.5f;

    private bool gunFacingRight;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector3 direction = mousePos - transform.position;

        gun.rotation = Quaternion.Euler(new Vector3(0, 0, Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg));

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        gun.position = transform.position + Quaternion.Euler(0,0,angle) * new Vector3(gunDistance, 0, 0);


        if(mousePos.x < gun.position.x && gunFacingRight)
        {
            gunFacingRight = !gunFacingRight;
            gun.localScale = new Vector3(gun.localScale.x, gun.localScale.y * -1, gun.localScale.z);
        }
        else if(mousePos.x > transform.position.x && !gunFacingRight)
        {
            
        }


        
    }


    public void OnShoot()
    {
        GameObject newBullet = Instantiate(bullet, gunObject.transform.position, Quaternion.identity);
        //newBullet = 
        newBullet.GetComponent<Rigidbody2D>().AddForce(gunObject.transform.right * speed, ForceMode2D.Impulse);
        newBullet.transform.right = gunObject.transform.right;
        
        
        //newBullet.GetComponent<SelfDestruct>().Shooter = gameObject;
    }
}
