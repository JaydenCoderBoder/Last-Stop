using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMove : MonoBehaviour
{



    //public Transform enemy;
    public float speed = 2f;

    // Start is called before the first frame update
    void Start()
    {
        //isRight = True;
    }

    // Update is called once per frame
    void Update()
    {
        // if(isRight == True)
        // {
            transform.position += transform.right * speed * Time.deltaTime;
        //} 
        // if(isRight == False)
        // {
        //     enemy.position -= Vector3.right * speed * Time.deltaTime;
        // }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        
        if(col.gameObject.CompareTag("Patrol Point"))
        {
            speed = speed * -1;
            Flip();
        }
       
    }
    void Flip()
    {
        Vector3 scaler = transform.localScale;
        scaler.x *= -1;
        transform.localScale = scaler;
    }
}
