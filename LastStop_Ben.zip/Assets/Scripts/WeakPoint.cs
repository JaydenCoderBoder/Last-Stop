using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeakPoint : MonoBehaviour
{
    public Transform WeakPointPos;
    public Vector3 Offset;
    //public Transform parent;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = WeakPointPos.position +Offset;
        //transform.position = WeakPointPos.position;
        // if(WeakPointPos == null)
        // {
        //     Destroy (gameObject);
        // }
    }
}
