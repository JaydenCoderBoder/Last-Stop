using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerScrpt : MonoBehaviour
{
    [SerializeField] GameObject thingSpawned;
    [SerializeField] private float coolDown = 0.3f;
    float timer;
    // Start is called before the first frame update
    void Start()
    {
        timer = coolDown;
    }

    // Update is called once per frame
    void Update()
    {
        timer = timer - Time.deltaTime; //timer -= Time.deltaTime;
        if(timer <= 0)
        {
            transform.position = new Vector3(Random.Range(85f, 140f), 25, 0);
            Instantiate(thingSpawned, transform.position, Quaternion.identity);
            timer  = coolDown;
        }
    }
        void OnCollisionEnter2D(Collision2D collision)
    {   
        if(collision.gameObject.CompareTag("Wall") && (collision.gameObject.CompareTag("Spike")))
        {
            Destroy(collision.gameObject);
        }
    }      
}
